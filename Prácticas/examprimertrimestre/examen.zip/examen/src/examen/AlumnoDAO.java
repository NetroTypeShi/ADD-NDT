package examen;

import java.sql.*;
import java.util.ArrayList;

public class AlumnoDAO {

    private Connection conn;

    public AlumnoDAO() {
        conn = ConexionBD.getConexion();
    }

    //Insertar entrenador
    public void insertarAlumno(Alumno e) {
        String sql = "INSERT INTO alumnos (nombre, curso) VALUES (?, ?)";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, e.getNombre());
            stmt.setInt(2, e.getN_curso());

            stmt.executeUpdate();
            System.out.println("Almuno insertado correctamente.");

        } catch (SQLException ex) {
            System.err.println("Error al insertar alumno:");
            ex.printStackTrace();
        }
    }

    // Eliminar entrenador por ID
    public void eliminarAlumno(int id) {
        String sql = "DELETE FROM alumnos WHERE id = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            stmt.executeUpdate();
            System.out.println("Alumno eliminado correctamente.");

        } catch (SQLException ex) {
            System.err.println("Error al eliminar Alumno:");
            ex.printStackTrace();
        }
    }

    // Lista todos los entrenadores
    public ArrayList<Alumno> listarAlumnos() {
        ArrayList<Alumno> lista = new ArrayList<>();
        String sql = "SELECT * FROM alumnos";

        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Alumno e = new Alumno(
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getInt("curso")
                );
                lista.add(e);
            }

        } catch (SQLException ex) {
            System.err.println("Error al listar alumnos:");
            ex.printStackTrace();
        }

        return lista;
    }

    // Poner el curso del alumno
    public void ponerCurso(int id) {
        String sql = "UPDATE alumnos SET curso = curso WHERE id = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            stmt.executeUpdate();
            System.out.println("Curso guardado correctamente.");

        } catch (SQLException ex) {
            System.err.println("Error al poner curso:");
            ex.printStackTrace();
        }
    }
}

