package examen;

public class Alumno {

    private int id;
    private String nombre;
    private int curso;

    // Constructor sin ID (pa insertar)
    public Alumno(String nombre, int curso) {
        this.nombre = nombre;
        this.curso = curso;
    }

    // Constructor con ID (pa leer de la BD)
    public Alumno(int id, String nombre, int curso) {
        this.id = id;
        this.nombre = nombre;
        this.curso = curso;
    }

    // Getters y Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public int getN_curso() { return curso; }
    public void setN_curso(int curso) { this.curso = curso; }
}







