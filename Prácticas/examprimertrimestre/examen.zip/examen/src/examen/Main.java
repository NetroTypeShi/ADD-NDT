package examen;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        
        AlumnoDAO alumnoDAO = new AlumnoDAO();

        int opcion;

        do {
            System.out.println("MENÚ PRINCIPAL ALUMNOS");
            System.out.println("1. Añadir alumno");
            System.out.println("2. Eliminar alumno");
            System.out.println("3. Listar alumnos");
            System.out.println("0. Salir");
            System.out.print("Elige una opción: ");

            opcion = sc.nextInt();
            sc.nextLine();

            switch (opcion) {

                //Añadir alumno
                case 1:
                    System.out.print("Nombre del Alumno: ");
                    String nombreA = sc.nextLine();

                    System.out.print("Número de curso: ");
                    int curso = sc.nextInt();
                    sc.nextLine();

                    Alumno e = new Alumno(nombreA, curso);
                    alumnoDAO.insertarAlumno(e);
                    break;


                // Eliminar alumno
                case 2:
                    System.out.print("ID del alumno a eliminar: ");
                    int idEliminarE = sc.nextInt();
                    sc.nextLine();

                    alumnoDAO.eliminarAlumno(idEliminarE);
                    break;


                // Listar alumnos
                case 3:
                    ArrayList<Alumno> alumnos = alumnoDAO.listarAlumnos();
                    System.out.println("ALUMNOS");
                    for (Alumno en : alumnos) {
                        System.out.println("ID: " + en.getId() +
                                           " | Nombre: " + en.getNombre() +
                                           " | Curso: " + en.getN_curso());
                    }
                    break;

                case 0:
                    System.out.println("Cerrando programa...");
                    ConexionBD.cerrarConexion();
                    break;

                default:
                    System.out.println("Opción no válida.");
            }

        } while (opcion != 0);

        sc.close();
    }
}

